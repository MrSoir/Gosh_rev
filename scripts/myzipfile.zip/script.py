import numpy as np
import argparse
import os
import tkinter # note that module name has changed from Tkinter in Python 2 to tkinter in Python 3

def main_gui():
    top = tkinter.Tk()
    top.mainloop()

def main():
    parser = argparse.ArgumentParser(description='zip files')
    parser.add_argument('-t', '--target_path', help='first argument', required=False)
    parser.add_argument('-s', '--source_paths', nargs='+', help='first argument', required=False)
    
    args = parser.parse_args()
    
    if args.target_path is not None:
        print('target_path is: ', args.target_path)
    else:
        print('target_path not set')
                
    if args.source_paths is not None:
        print('sourc_paths are: ', args.source_paths)
    else:
        print('sourc_paths not set')
    
    script_dir = os.path.dirname(os.path.abspath(__file__))
    filename = 'script_rslt.txt'
    with open(os.path.join(script_dir, filename), 'w') as out:
        if args.target_path is not None:
            out.write('target_path: ' + str(args.target_path) + '\n')
        else:
            out.write('target_path: None')
        
        if args.source_paths is not None:
            out.write('source_paths: ' + ''.join(str(x) + ", " for x in args.source_paths))
        else:
            out.write('source_paths: None')
    
if __name__ == "__main__":
    main()

